package pl.uczelnia.ekopanel.service;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.*;
import pl.uczelnia.ekopanel.model.*;

public class StatisticsService {
    public Statistics calculate(List<Observation> rows) {
        List<BigDecimal> vals = rows.stream()
                .filter(o -> o.included() && o.value() != null)
                .map(Observation::value)
                .sorted()
                .toList();
        int n = vals.size();
        if (n == 0) return new Statistics(0, null, null, null, null, null, null);
        BigDecimal sum = BigDecimal.ZERO;
        for (BigDecimal v : vals) sum = sum.add(v);
        BigDecimal mean4 = sum.divide(BigDecimal.valueOf(n), 4, RoundingMode.HALF_UP);
        BigDecimal mean = mean4.setScale(2, RoundingMode.HALF_UP);
        BigDecimal median = (n % 2 == 1)
                ? vals.get(n / 2).setScale(2, RoundingMode.HALF_UP)
                : vals.get(n / 2 - 1).add(vals.get(n / 2)).divide(BigDecimal.valueOf(2), 2, RoundingMode.HALF_UP);
        BigDecimal absSum = BigDecimal.ZERO;
        BigDecimal sqSum = BigDecimal.ZERO;
        for (BigDecimal v : vals) {
            BigDecimal diff = v.subtract(mean4);
            absSum = absSum.add(diff.abs());
            sqSum = sqSum.add(diff.multiply(diff));
        }
        BigDecimal mad = absSum.divide(BigDecimal.valueOf(n), 2, RoundingMode.HALF_UP);
        BigDecimal sd = n > 1
                ? sqSum.divide(BigDecimal.valueOf(n - 1), 8, RoundingMode.HALF_UP)
                    .sqrt(MathContext.DECIMAL64).setScale(2, RoundingMode.HALF_UP)
                : null;
        return new Statistics(n, vals.getFirst(), vals.getLast(), mean, median, sd, mad);
    }
}
