package pl.uczelnia.ekopanel.io;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import pl.uczelnia.ekopanel.model.*;
import pl.uczelnia.ekopanel.service.*;

public class GusCsvPackageReader {
    public List<Region> readRegions(Path path) throws IOException {
        List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
        if (lines.isEmpty() || !lines.getFirst().strip().equals("code;name;macroregion")) {
            throw new IOException("Nieprawidłowy nagłówek regions.csv");
        }
        List<Region> list = new ArrayList<>();
        for (int i = 1; i < lines.size(); i++) {
            if (lines.get(i).isBlank()) continue;
            String[] p = lines.get(i).split(";", -1);
            list.add(new Region(p[0].strip(), p[1].strip(), p[2].strip()));
        }
        return list;
    }

    public List<Indicator> readIndicators(Path path) throws IOException {
        List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
        if (lines.isEmpty() || !lines.getFirst().strip().equals("code;name;unit;category")) {
            throw new IOException("Nieprawidłowy nagłówek indicators.csv");
        }
        List<Indicator> list = new ArrayList<>();
        for (int i = 1; i < lines.size(); i++) {
            if (lines.get(i).isBlank()) continue;
            String[] p = lines.get(i).split(";", -1);
            list.add(new Indicator(p[0].strip(), p[1].strip(), p[2].strip(), p[3].strip()));
        }
        return list;
    }

    public List<Observation> readObservations(Path path, Map<String, Region> regs, Map<String, Indicator> inds) throws IOException {
        List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
        if (lines.isEmpty() || !lines.getFirst().strip().equals("year;region_code;indicator_code;value;included")) {
            throw new IOException("Nieprawidłowy nagłówek observations.csv");
        }
        List<Observation> list = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (int i = 1; i < lines.size(); i++) {
            String line = lines.get(i);
            if (line.isBlank()) continue;
            int lineNo = i + 1;
            try {
                String[] p = line.split(";", -1);
                int year = Integer.parseInt(p[0].strip());
                String regCode = p[1].strip();
                String indCode = p[2].strip();
                if (!regs.containsKey(regCode)) throw new IllegalArgumentException("Nieznany kod regionu: " + regCode + ".");
                Indicator ind = inds.get(indCode);
                if (ind == null) throw new IllegalArgumentException("Nieznany kod wskaźnika: " + indCode + ".");
                BigDecimal val = Numbers.parseDecimal(p[3]);
                ObservationValidator.validate(year, regCode, indCode, val, ind);
                String key = year + "|" + regCode + "|" + indCode;
                if (!seen.add(key)) throw new IllegalArgumentException("Duplikat obserwacji: " + key);
                boolean inc = Boolean.parseBoolean(p[4].strip());
                list.add(new Observation(null, year, regCode, indCode, val, inc));
            } catch (RuntimeException ex) {
                throw new IOException("Wiersz " + lineNo + ": " + ex.getMessage(), ex);
            }
        }
        return list;
    }
}
