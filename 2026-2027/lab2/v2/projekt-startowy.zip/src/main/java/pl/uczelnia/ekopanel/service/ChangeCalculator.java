package pl.uczelnia.ekopanel.service;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class ChangeCalculator {
    public BigDecimal difference(BigDecimal start, BigDecimal end) {
        return end.subtract(start).setScale(2, RoundingMode.HALF_UP);
    }
    public BigDecimal relativeChange(BigDecimal start, BigDecimal end) {
        if (start.compareTo(BigDecimal.ZERO) == 0) {
            throw new IllegalArgumentException("Nie można obliczyć zmiany względnej dla zera.");
        }
        return end.subtract(start).multiply(new BigDecimal("100")).divide(start, 2, RoundingMode.HALF_UP);
    }
    public BigDecimal dynamicsIndex(BigDecimal start, BigDecimal end) {
        if (start.compareTo(BigDecimal.ZERO) == 0) {
            throw new IllegalArgumentException("Nie można obliczyć zmiany względnej dla zera.");
        }
        return end.multiply(new BigDecimal("100")).divide(start, 2, RoundingMode.HALF_UP);
    }
}
