package pl.uczelnia.ekopanel.service;

import java.util.*;
import pl.uczelnia.ekopanel.model.*;
import pl.uczelnia.ekopanel.repository.ObservationRepository;

public class ObservationService {
    private final ObservationRepository repo;

    public ObservationService(ObservationRepository repo) {
        this.repo = Objects.requireNonNull(repo);
    }

    public List<Region> findAllRegions() { return repo.findAllRegions(); }
    public List<Indicator> findAllIndicators() { return repo.findAllIndicators(); }
    public List<Observation> findAllObservations() { return repo.findAllObservations(); }

    public Observation save(Observation obs) {
        Objects.requireNonNull(obs, "Obserwacja nie może być pusta.");
        Region reg = repo.findAllRegions().stream()
                .filter(r -> r.code().equals(obs.regionCode()))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Nieznany kod regionu: " + obs.regionCode() + "."));
        Indicator ind = repo.findAllIndicators().stream()
                .filter(i -> i.code().equals(obs.indicatorCode()))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Nieznany kod wskaźnika: " + obs.indicatorCode() + "."));
        ObservationValidator.validate(obs.year(), reg.code(), ind.code(), obs.value(), ind);
        boolean duplicate = repo.findAllObservations().stream().anyMatch(o ->
                !Objects.equals(o.id(), obs.id())
                        && o.year() == obs.year()
                        && o.regionCode().equals(obs.regionCode())
                        && o.indicatorCode().equals(obs.indicatorCode()));
        if (duplicate) {
            throw new IllegalArgumentException("Obserwacja dla tego roku, regionu i wskaźnika już istnieje.");
        }
        return repo.save(obs);
    }

    public void delete(long id) {
        repo.delete(id);
    }

    public void replaceDataset(List<Region> regions, List<Indicator> indicators, List<Observation> observations) {
        Map<String, Region> regMap = new LinkedHashMap<>();
        for (Region r : regions) {
            if (regMap.put(r.code(), r) != null) {
                throw new IllegalArgumentException("Duplikat kodu regionu w słowniku: " + r.code());
            }
        }
        Map<String, Indicator> indMap = new LinkedHashMap<>();
        for (Indicator ind : indicators) {
            if (indMap.put(ind.code(), ind) != null) {
                throw new IllegalArgumentException("Duplikat kodu wskaźnika w słowniku: " + ind.code());
            }
        }
        Set<String> seenKeys = new HashSet<>();
        for (Observation obs : observations) {
            Region reg = regMap.get(obs.regionCode());
            if (reg == null) {
                throw new IllegalArgumentException("Nieznany kod regionu: " + obs.regionCode() + ".");
            }
            Indicator ind = indMap.get(obs.indicatorCode());
            if (ind == null) {
                throw new IllegalArgumentException("Nieznany kod wskaźnika: " + obs.indicatorCode() + ".");
            }
            ObservationValidator.validate(obs.year(), reg.code(), ind.code(), obs.value(), ind);
            String key = obs.year() + "|" + reg.code() + "|" + ind.code();
            if (!seenKeys.add(key)) {
                throw new IllegalArgumentException("Obserwacja dla tego roku, regionu i wskaźnika już istnieje.");
            }
        }
        repo.replaceDataset(List.copyOf(regMap.values()), List.copyOf(indMap.values()), observations);
    }
}
