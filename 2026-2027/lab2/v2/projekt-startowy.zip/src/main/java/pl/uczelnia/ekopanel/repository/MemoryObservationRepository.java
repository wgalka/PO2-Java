package pl.uczelnia.ekopanel.repository;

import java.util.ArrayList;
import java.util.List;
import pl.uczelnia.ekopanel.model.*;

public class MemoryObservationRepository implements ObservationRepository {
    private List<Region> regions = new ArrayList<>();
    private List<Indicator> indicators = new ArrayList<>();
    private List<Observation> observations = new ArrayList<>();
    private long nextId = 1;

    public MemoryObservationRepository() {
        regions.addAll(List.of(
                new Region("PL82", "Podkarpackie", "Wschodni"),
                new Region("PL21", "Małopolskie", "Południowy"),
                new Region("PL22", "Śląskie", "Południowy"),
                new Region("PL91", "Mazowieckie", "Województwo mazowieckie"),
                new Region("PL41", "Wielkopolskie", "Północno-zachodni")
        ));
        indicators.addAll(List.of(
                new Indicator("UNEMP_RATE", "Stopa bezrobocia rejestrowanego", "%", "Rynek pracy"),
                new Indicator("AVG_WAGE", "Przeciętne miesięczne wynagrodzenie brutto", "PLN", "Wynagrodzenia"),
                new Indicator("INV_PER_CAPITA", "Nakłady inwestycyjne na 1 mieszkańca", "PLN", "Inwestycje")
        ));
    }

    @Override public List<Region> findAllRegions() { return List.copyOf(regions); }
    @Override public List<Indicator> findAllIndicators() { return List.copyOf(indicators); }
    @Override public List<Observation> findAllObservations() { return List.copyOf(observations); }

    @Override
    public Observation save(Observation observation) {
        if (observation.id() == null) {
            Observation saved = new Observation(nextId++, observation.year(),
                    observation.regionCode(), observation.indicatorCode(),
                    observation.value(), observation.included());
            observations.add(saved);
            return saved;
        }
        for (int i = 0; i < observations.size(); i++) {
            if (observation.id().equals(observations.get(i).id())) {
                observations.set(i, observation);
                return observation;
            }
        }
        throw new IllegalArgumentException("Nie znaleziono obserwacji.");
    }

    @Override
    public void delete(long id) {
        if (!observations.removeIf(o -> o.id() != null && o.id() == id)) {
            throw new IllegalArgumentException("Nie znaleziono obserwacji.");
        }
    }

    @Override
    public void replaceDataset(List<Region> regs, List<Indicator> inds, List<Observation> obs) {
        List<Region> newRegs = new ArrayList<>(regs);
        List<Indicator> newInds = new ArrayList<>(inds);
        List<Observation> newObs = new ArrayList<>();
        long id = 1;
        for (Observation o : obs) {
            newObs.add(new Observation(id++, o.year(), o.regionCode(), o.indicatorCode(), o.value(), o.included()));
        }
        this.regions = newRegs;
        this.indicators = newInds;
        this.observations = newObs;
        this.nextId = id;
    }
}
